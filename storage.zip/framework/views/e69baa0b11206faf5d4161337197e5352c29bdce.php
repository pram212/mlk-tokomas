<?php $__env->startSection('title', trans('file.Gramasi')); ?>
<?php $__env->startSection('content'); ?>
<?php if(session()->has('create_message')): ?>
<div class="alert alert-success alert-dismissible text-center"><button type="button" class="close" data-dismiss="alert"
        aria-label="Close"><span aria-hidden="true">&times;</span></button><?php echo e(session()->get('create_message')); ?></div>
<?php endif; ?>
<?php if(session()->has('edit_message')): ?>
<div class="alert alert-success alert-dismissible text-center"><button type="button" class="close" data-dismiss="alert"
        aria-label="Close"><span aria-hidden="true">&times;</span></button><?php echo e(session()->get('edit_message')); ?></div>
<?php endif; ?>
<?php if(session()->has('import_message')): ?>
<div class="alert alert-success alert-dismissible text-center"><button type="button" class="close" data-dismiss="alert"
        aria-label="Close"><span aria-hidden="true">&times;</span></button><?php echo e(session()->get('import_message')); ?></div>
<?php endif; ?>
<?php if(session()->has('not_permitted')): ?>
<div class="alert alert-danger alert-dismissible text-center"><button type="button" class="close" data-dismiss="alert"
        aria-label="Close"><span aria-hidden="true">&times;</span></button><?php echo e(session()->get('not_permitted')); ?></div>
<?php endif; ?>
<?php if(session()->has('message')): ?>
<div class="alert alert-danger alert-dismissible text-center"><button type="button" class="close" data-dismiss="alert"
        aria-label="Close"><span aria-hidden="true">&times;</span></button><?php echo e(session()->get('message')); ?></div>
<?php endif; ?>

<section>
    <div class="container-fluid">
        
        <a href="<?php echo e(route('product-categories.gramasi.create')); ?>" class="btn btn-info"><i class="dripicons-plus"></i>
            <?php echo e(__('file.Add Gramasi')); ?></a>
        
    </div>
    <div class="table-responsive">
        <table id="gramasi-datatable" class="table" style="width: 100%">
            <thead>
                <tr>
                    <th class="not-exported"></th>
                    <th><?php echo e(__('file.Product Gramasi Type Code')); ?></th>
                    <th><?php echo e(__('file.Product Category')); ?></th>
                    <th><?php echo e(__('file.Product Type')); ?></th>
                    <th><?php echo e(__('file.Gramasi')); ?></th>
                    <th class="not-exported"><?php echo e(trans('file.action')); ?></th>
                </tr>
            </thead>

        </table>
    </div>
</section>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    const lang_records_per_page = '<?php echo e(trans('file.records per page')); ?>';
    const lang_Showing = '<?php echo e(trans('file.Showing')); ?>' ;
    const lang_search = '<?php echo e(trans('file.Search')); ?>' ;
    const lang_PDF = '<?php echo e(trans('file.PDF')); ?>';
    const lang_CSV = '<?php echo e(trans('file.CSV')); ?>';
    const lang_print = '<?php echo e(trans('file.Print')); ?>';
    const lang_delete = '<?php echo e(trans('file.delete')); ?>';
    const lang_visibility = '<?php echo e(trans('file.Column visibility')); ?>';
    const lang_gramasi = '<?php echo e(trans('file.Gramasi')); ?>';
</script>
<script src="<?php echo e(asset('public/js/pages/gramasi/gramasi_index.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tokomas\resources\views/gramasi/index.blade.php ENDPATH**/ ?>