 <?php $__env->startSection('content-pos'); ?>
<?php if($errors->has('phone_number')): ?>
<div class="alert alert-danger alert-dismissible text-center">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
            aria-hidden="true">&times;</span></button><?php echo e($errors->first('phone_number')); ?>

</div>
<?php endif; ?>
<?php if(session()->has('message')): ?>
<div class="alert alert-success alert-dismissible text-center"><button type="button" class="close" data-dismiss="alert"
        aria-label="Close"><span aria-hidden="true">&times;</span></button><?php echo session()->get('message'); ?></div>
<?php endif; ?>
<?php if(session()->has('not_permitted')): ?>
<div class="alert alert-danger alert-dismissible text-center"><button type="button" class="close" data-dismiss="alert"
        aria-label="Close"><span aria-hidden="true">&times;</span></button><?php echo e(session()->get('not_permitted')); ?></div>
<?php endif; ?>

<section id="pos-section">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <?php echo $__env->make('sale.partials.pos_transaction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="col-md-6">
                <?php echo $__env->make('sale.partials.pos_information', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('public/css/pages/sales/sales_pos_new.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('public/js/pages/sales/sales_pos_new.js?timestamp=' . now()->timestamp)); ?>"></script>
<script src="<?php echo e(asset('public/js/pages/sales/sales_pos_cart.js?timestamp=' . now()->timestamp)); ?>"></script>
<script src="<?php echo e(asset('public/js/pages/sales/sales_pos_info.js?timestamp=' . now()->timestamp)); ?>"></script>
<script src="<?php echo e(asset('public/js/pages/sales/sales_pos_payment.js?timestamp=' . now()->timestamp)); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', ['pos_view' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tokomas\resources\views/sale/pos_new.blade.php ENDPATH**/ ?>