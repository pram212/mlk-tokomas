<?php $__env->startSection('title', trans('file.Price')); ?>
<?php $__env->startSection('content'); ?>
<section>
    <div class="container-fluid">
        <h3><?php echo e(trans('file.Gold Price')); ?> - <?php echo e(date('d M Y')); ?></h3>
        <hr>
        
        <a href="<?php echo e(route('master.price.create')); ?>" class="btn btn-info"><i class="dripicons-plus"></i>
            <?php echo e(__('file.Add Price')); ?></a>
        
    </div>
    <div class="table-responsive">
        <table id="price-datatable" class="table" style="width: 100%">
            <thead>
                <tr>
                    <th class="not-exported"></th>
                    <th><?php echo e(__('file.Tag Type')); ?></th>
                    <th><?php echo e(__('file.Gramasi')); ?></th>
                    <th><?php echo e(__('file.Carat')); ?></th>
                    <th><?php echo e(__('file.category')); ?></th>
                    <th><?php echo e(__('file.Product Type')); ?></th>
                    <th><?php echo e(__('file.Created By')); ?></th>
                    <th><?php echo e(__('file.Updated By')); ?></th>
                    <th><?php echo e(__('file.Created At')); ?></th>
                    <th><?php echo e(__('file.Updated At')); ?></th>
                    <th class="not-exported"><?php echo e(trans('file.action')); ?></th>
                </tr>
            </thead>

        </table>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    const lang_records_per_page = '<?php echo e(trans('file.records per page')); ?>';
    const lang_Showing = '<?php echo e(trans('file.Showing')); ?>' ;
    const lang_search = '<?php echo e(trans('file.Search')); ?>' ;
    const lang_PDF = '<?php echo e(trans('file.PDF')); ?>';
    const lang_CSV = '<?php echo e(trans('file.CSV')); ?>';
    const lang_print = '<?php echo e(trans('file.Print')); ?>';
    const lang_delete = '<?php echo e(trans('file.delete')); ?>';
    const lang_visibility = '<?php echo e(trans('file.Column visibility')); ?>';
    const lang_price = '<?php echo e(trans('file.price')); ?>';
</script>
<script src="<?php echo e(asset('public/js/pages/price/price_index.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tokomas\resources\views/price/index.blade.php ENDPATH**/ ?>