<div id="order-tax" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true"
    class="modal fade text-left">
    <div role="document" class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><?php echo e(trans('file.Order Tax')); ?></h5>
                <button type="button" data-dismiss="modal" aria-label="Close" class="close"><span
                        aria-hidden="true"><i class="dripicons-cross"></i></span></button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <input type="hidden" name="order_tax_rate">
                    <select class="form-control" name="order_tax_rate_select" id="order-tax-rate-select">
                        <option value="0">No Tax</option>
                        <?php $__currentLoopData = $lims_tax_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tax): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($tax->rate); ?>"><?php echo e($tax->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <button type="button" name="order_tax_btn" class="btn btn-primary"
                    data-dismiss="modal"><?php echo e(trans('file.submit')); ?></button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\laragon\www\mlk-tokomas\resources\views/sale/order_tax.blade.php ENDPATH**/ ?>