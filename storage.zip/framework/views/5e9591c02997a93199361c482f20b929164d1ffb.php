<div id="view-payment" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true"
  class="modal fade text-left">
  <div role="document" class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 id="exampleModalLabel" class="modal-title"><?php echo e(trans('file.All')); ?> <?php echo e(trans('file.Payment')); ?></h5>
        <button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true"><i
              class="dripicons-cross"></i></span></button>
      </div>
      <div class="modal-body">
        <table class="table table-hover payment-list">
          <thead>
            <tr>
              <th><?php echo e(trans('file.No')); ?></th>
              <th><?php echo e(trans('file.date')); ?></th>
              <th><?php echo e(trans('file.reference')); ?></th>
              <th><?php echo e(trans('file.Account')); ?></th>
              <th><?php echo e(trans('file.Amount')); ?></th>
              <th><?php echo e(trans('file.Paid By')); ?></th>
            </tr>
          </thead>
          <tbody>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\laragon\www\tokomas\resources\views/sale/partials/modal_sale_view_payment.blade.php ENDPATH**/ ?>