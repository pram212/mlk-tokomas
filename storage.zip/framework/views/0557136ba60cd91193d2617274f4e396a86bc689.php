<div id="recentTransaction" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" class="modal fade text-left">
    <div role="document" class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 id="exampleModalLabel" class="modal-title"><?php echo e(trans('file.Recent Transaction')); ?> <div class="badge badge-primary"><?php echo e(trans('file.latest')); ?> 10</div></h5>
          <button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true"><i class="dripicons-cross"></i></span></button>
        </div>
        <div class="modal-body">
            <ul class="nav nav-tabs" role="tablist">
              <li class="nav-item">
                <a class="nav-link active" href="#sale-latest" role="tab" data-toggle="tab"><?php echo e(trans('file.Sale')); ?></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#draft-latest" role="tab" data-toggle="tab"><?php echo e(trans('file.Draft')); ?></a>
              </li>
            </ul>
            <div class="tab-content">
              <div role="tabpanel" class="tab-pane show active" id="sale-latest">
                  <div class="table-responsive">
                    <table class="table">
                      <thead>
                        <tr>
                          <th><?php echo e(trans('file.date')); ?></th>
                          <th><?php echo e(trans('file.reference')); ?></th>
                          <th><?php echo e(trans('file.customer')); ?></th>
                          <th><?php echo e(trans('file.grand total')); ?></th>
                          <th><?php echo e(trans('file.action')); ?></th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $recent_sale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e(date('d-m-Y', strtotime($sale->created_at))); ?></td>
                          <td><?php echo e($sale->reference_no); ?></td>
                          <td><?php echo e($sale->customer->name); ?></td>
                          <td><?php echo e($sale->grand_total); ?></td>
                          <td>
                            <div class="btn-group">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $sale->id)): ?>
                                <a href="<?php echo e(route('sales.edit', $sale->id)); ?>" class="btn btn-success btn-sm" title="Edit">
                                    <i class="dripicons-document-edit"></i>
                                </a>&nbsp;    
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('destroy', $sale->id)): ?>
                                <?php echo e(Form::open(['route' => ['sales.destroy', $sale->id], 'method' => 'DELETE'] )); ?>

                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirmDelete()" title="Delete">
                                    <i class="dripicons-trash"></i>
                                </button>
                                <?php echo e(Form::close()); ?>

                                <?php endif; ?>
                            </div>
                          </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                  </div>
              </div>
              <div role="tabpanel" class="tab-pane fade" id="draft-latest">
                  <div class="table-responsive">
                    <table class="table">
                      <thead>
                        <tr>
                          <th><?php echo e(trans('file.date')); ?></th>
                          <th><?php echo e(trans('file.reference')); ?></th>
                          <th><?php echo e(trans('file.customer')); ?></th>
                          <th><?php echo e(trans('file.grand total')); ?></th>
                          <th><?php echo e(trans('file.action')); ?></th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $recent_draft; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $draft): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e(date('d-m-Y', strtotime($draft->created_at))); ?></td>
                          <td><?php echo e($draft->reference_no); ?></td>
                          <td><?php echo e($sale->customer->name); ?></td>
                          <td><?php echo e($draft->grand_total); ?></td>
                          <td>
                            <div class="btn-group">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $sale)): ?>
                                <a href="<?php echo e(url('sales/'.$draft->id.'/create')); ?>" class="btn btn-success btn-sm" title="Edit">
                                    <i class="dripicons-document-edit"></i>
                                </a>&nbsp;
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $sale)): ?>
                                <?php echo e(Form::open(['route' => ['sales.destroy', $draft->id], 'method' => 'DELETE'] )); ?>

                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirmDelete()" title="Delete">
                                        <i class="dripicons-trash"></i>
                                    </button>
                                <?php echo e(Form::close()); ?>

                                <?php endif; ?>

                            </div>
                          </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                  </div>
              </div>
            </div>
        </div>
      </div>
    </div>
</div><?php /**PATH D:\laragon\www\mlk-tokomas\resources\views/sale/recent_transaction.blade.php ENDPATH**/ ?>