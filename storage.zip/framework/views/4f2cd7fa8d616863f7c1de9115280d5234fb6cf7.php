<nav class="side-navbar shrink">
    <div class="side-navbar-wrapper">
        <!-- Sidebar Header    -->
        <!-- Sidebar Navigation Menus-->
        <div class="main-menu">
            <ul id="side-main-menu" class="side-menu list-unstyled">
                <li>
                    <a href="<?php echo e(url('/')); ?>">
                        <i class="dripicons-meter"></i><span><?php echo e(__('file.dashboard')); ?></span>
                    </a>
                </li>

                
                <li>
                    <?php
                    $requestIsOnProductCategoryMenu = request()->is('product-categories*', 'master*',
                    'category*','promo*') ?
                    'true' : 'false';
                    ?>
                    <a href="#productcategory" data-toggle="collapse"
                        aria-expanded="<?php echo e($requestIsOnProductCategoryMenu); ?>">
                        <i class="dripicons-card"></i><span>Master</span>
                    </a>

                    <ul id="productcategory"
                        class="collapse list-unstyled <?php if($requestIsOnProductCategoryMenu === 'true'): ?> show <?php endif; ?>">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', App\Category::class)): ?>
                        <li id="category-menu" class="<?php if(request()->is('category*')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('category.index')); ?>"><?php echo e(__('file.Product Category')); ?></a>
                        </li>
                        <?php endif; ?>

                        <li id="productcategory-list-menu"
                            class="<?php if(request()->is('product-categories/tagtype*')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('product-categories.tagtype.index')); ?>"><?php echo e(__('file.Tagging Type')); ?></a>
                        </li>
                        <li id="productcategory-list-menu"
                            class="<?php if(request()->is('product-categories/productproperty*')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('product-categories.productproperty.index')); ?>">
                                <?php echo e(__('file.Product Property')); ?></a>
                        </li>
                        <li id="productcategory-list-menu"
                            class="<?php if(request()->is('product-categories/producttype*')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('product-categories.producttype.index')); ?>"><?php echo e(__('file.Product Type')); ?></a>
                        </li>
                        <li id="productcategory-list-menu"
                            class="<?php if(request()->is('product-categories/gramasi*')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('product-categories.gramasi.index')); ?>"><?php echo e(__('file.Gramasi List')); ?></a>
                        </li>
                        <li id="price-list-menu" class="<?php if(request()->is('master/price*')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('master.price.index')); ?>"><?php echo e(__('file.Price')); ?></a>
                        </li>
                        <li id="promo" class="<?php if(request()->is('promo*')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(url('promo')); ?>"><?php echo e(__('file.promo')); ?></a>
                        </li>

                    </ul>
                </li>
                

                <li>
                    <?php
                    $requestIsOnProductMenu = request()->is(
                    'products*',
                    'category*',
                    'qty_adjustment*',
                    'stock-count*',
                    'product_stock*',
                    'warehouse_transfer*',
                    )
                    ? 'true'
                    : 'false';
                    ?>
                    <a href="#product" data-toggle="collapse" aria-expanded="<?php echo e($requestIsOnProductMenu); ?>">
                        <i class="dripicons-list"></i><span><?php echo e(__('file.product')); ?></span><span>
                    </a>
                    <ul id="product"
                        class="collapse list-unstyled <?php if($requestIsOnProductMenu === 'true'): ?> show <?php endif; ?>">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', App\Category::class)): ?>
                        <li id="category-menu" class="<?php echo e(request()->is('category*') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('category.index')); ?>"><?php echo e(__('file.category')); ?></a>
                        </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', App\Product::class)): ?>
                        <li id="product-list-menu" class="<?php echo e(request()->is('products/') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('products.index')); ?>"><?php echo e(__('file.product_list')); ?></a>
                        </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Product::class)): ?>
                        <li id="product-create-menu" class="<?php echo e(request()->is('products/create') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('products.create')); ?>"><?php echo e(__('file.add_product')); ?></a>
                        </li>
                        <?php endif; ?>

                        <li id="warehouse_transfer" class="<?php echo e(request()->is('warehouse_transfer*') ? 'active' : ''); ?>">
                            <a href="<?php echo e(url('warehouse_transfer')); ?>"><?php echo e(__('file.warehouse_transfer')); ?></a>
                        </li>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('productsStock',App\Product::class)): ?>
                        <li id="product_stock" class="<?php echo e(request()->is('product_stock*') ? 'active' : ''); ?>">
                            <a href="<?php echo e(url('product_stock')); ?>"><?php echo e(__('file.product_stock')); ?></a>
                        </li>
                        <?php endif; ?>

                    </ul>
                </li>




                <li>
                    <?php
                    $requestIsOnSalesMenu = request()->is('sales*') ? 'true' : 'false';
                    ?>
                    <a href="#sale" aria-expanded="<?php echo e($requestIsOnSalesMenu); ?>" data-toggle="collapse">
                        <i class="dripicons-cart"></i><span><?php echo e(trans('file.Sale')); ?></span>
                    </a>
                    <ul id="sale" class="collapse list-unstyled <?php if($requestIsOnSalesMenu === 'true'): ?> show <?php endif; ?>">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', App\Sale::class)): ?>
                        <li id="sale-list-menu" class="<?php if(request()->is('sales')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('sales.index')); ?>"><?php echo e(trans('file.Sale List')); ?></a>
                        </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Sale::class)): ?>
                        <li class="<?php if(request()->is('sales/pos')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('sales.pos')); ?>" target="_blank">POS</a>
                        </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', App\Coupon::class)): ?>
                        <li id="coupon-menu" class="<?php if(request()->is('coupons*')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('coupons.index')); ?>"><?php echo e(trans('file.Coupon List')); ?></a>
                        </li>
                        <?php endif; ?>

                    </ul>
                </li>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', App\Product::class)): ?>
                <li id="buyback">
                    <a href="<?php echo e(url('buyback')); ?>">
                        <i class="dripicons-return"></i><span><?php echo e(__('file.buy back')); ?></span>
                    </a>
                </li>
                <?php endif; ?>



                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', App\Expense::class)): ?>
                <li>
                    <?php
                    $requestIsOnExpenseMenu = request()->is('expenses*') ? 'true' : 'false';
                    ?>
                    <a href="#expense" aria-expanded="<?php echo e($requestIsOnExpenseMenu); ?>" data-toggle="collapse">
                        <i class="dripicons-wallet"></i><span><?php echo e(trans('file.Expense')); ?></span>
                    </a>
                    <ul id="expense"
                        class="collapse list-unstyled <?php if($requestIsOnExpenseMenu === 'true'): ?> show <?php endif; ?> ">
                        <li id="exp-cat-menu" class="<?php if(request()->is('expense_categories/')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('expense_categories.index')); ?>"><?php echo e(trans('file.Expense Category')); ?></a>
                        </li>
                        <li id="exp-list-menu" class="<?php if(request()->is('expenses/')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('expenses.index')); ?>"><?php echo e(trans('file.Expense List')); ?></a>
                        </li>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Expense::class)): ?>
                        <li class="<?php if(request()->is('expenses/create')): ?> active <?php endif; ?>">
                            <a id="add-expense" href=""> <?php echo e(trans('file.Add Expense')); ?></a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', App\Quotation::class)): ?>
                <li>
                    <?php
                    $requestIsOnQuotationMenu = request()->is('quotations*') ? 'true' : 'false';
                    ?>
                    <a href="#quotation" aria-expanded="<?php echo e($requestIsOnQuotationMenu); ?>" data-toggle="collapse">
                        <i class="dripicons-document"></i><span><?php echo e(trans('file.Quotation')); ?></span><span>
                    </a>

                    <ul id="quotation"
                        class="collapse list-unstyled <?php if($requestIsOnQuotationMenu === 'true'): ?> show <?php endif; ?>">
                        <li class="<?php if(request()->is('quotations/')): ?> active <?php endif; ?>"">
                                <a href=" <?php echo e(route('quotations.index')); ?>"><?php echo e(trans('file.Quotation List')); ?></a>
                        </li>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Quotation::class)): ?>
                        <li class="<?php if(request()->is('quotations/create')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('quotations.create')); ?>"><?php echo e(trans('file.Add Quotation')); ?></a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </li>
                <?php endif; ?>

                <li>
                    <?php
                    $requestIsOnTransferMenu = request()->is('transfers*') ? 'true' : 'false';
                    ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', App\Transfer::class)): ?>
                    <a href="#transfer" aria-expanded="<?php echo e($requestIsOnTransferMenu); ?>" data-toggle="collapse">
                        <i class="dripicons-export"></i><span><?php echo e(trans('file.Transfer')); ?></span>
                    </a>
                    <?php endif; ?>
                    <ul id="transfer"
                        class="collapse list-unstyled <?php if($requestIsOnTransferMenu === 'true'): ?> show <?php endif; ?>">

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', App\Transfer::class)): ?>
                        <li class="<?php if(request()->is('transfers.index')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('transfers.index')); ?>"><?php echo e(trans('file.Transfer List')); ?></a>
                        </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Transfer::class)): ?>
                        <li class="<?php if(request()->is('transfers/create')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('transfers.create')); ?>"><?php echo e(trans('file.Add Transfer')); ?></a>
                        </li>
                        <li class="<?php if(request()->is('transfers/transfer_by_csv')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(url('transfers/transfer_by_csv')); ?>"><?php echo e(trans('file.Import Transfer By CSV')); ?></a>
                        </li>
                        <?php endif; ?>

                    </ul>
                </li>

                <li>
                    <?php
                    $requestIsOnReturnMenu = request()->is('return*') ? 'true' : 'false';
                    ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('return', App\Sale::class)): ?>
                    <a href="#return" aria-expanded="<?php echo e($requestIsOnReturnMenu); ?>" data-toggle="collapse">
                        <i class="dripicons-return"></i><span><?php echo e(trans('file.return')); ?></span>
                    </a>
                    <?php endif; ?>
                    <ul id="return" class="collapse list-unstyled <?php if($requestIsOnReturnMenu === 'true'): ?> show <?php endif; ?>">

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('return', App\Sale::class)): ?>
                        <li class="<?php if(request()->is('return-sale*')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('return-sale.index')); ?>"><?php echo e(trans('file.Sale')); ?></a>
                        </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('return', App\Purchase::class)): ?>
                        <li id="purchase-return-menu" class="<?php if(request()->is('return-purchase*')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('return-purchase.index')); ?>"><?php echo e(trans('file.Purchase')); ?></a>
                        </li>
                        <?php endif; ?>

                    </ul>
                </li>

                <li>
                    <?php
                    $requestIsOnAccountingMenu = request()->is('accounts*', 'money-transfers*', 'balancesheet*')
                    ? 'true'
                    : 'false';
                    ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', App\Account::class)): ?>
                    <a href="#account" aria-expanded="<?php echo e($requestIsOnAccountingMenu); ?>" data-toggle="collapse">
                        <i class="dripicons-briefcase"></i><span><?php echo e(trans('file.Accounting')); ?></span>
                    </a>
                    <?php endif; ?>
                    <ul id="account"
                        class="collapse list-unstyled <?php if($requestIsOnAccountingMenu === 'true'): ?> show <?php endif; ?>">

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', App\Account::class)): ?>
                        <li class="<?php if(request()->is('accounts/')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('accounts.index')); ?>"><?php echo e(trans('file.Account List')); ?></a>
                        </li>
                        <li class="<?php if(request()->is('accounts/create')): ?> active <?php endif; ?>">
                            <a id="add-account" href="#"><?php echo e(trans('file.Add Account')); ?></a>
                        </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', App\MoneyTransfer::class)): ?>
                        <li class="<?php if(request()->is('money-transfer/')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('money-transfers.index')); ?>"><?php echo e(trans('file.Money Transfer')); ?></a>
                        </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewBalanceSheet', App\Account::class)): ?>
                        <li class="<?php if(request()->is('accounts/balancesheet/')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('accounts.balancesheet')); ?>"><?php echo e(trans('file.Balance Sheet')); ?></a>
                        </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewStatement', App\Account::class)): ?>
                        <li class="<?php if(request()->is('accounts/statement/')): ?> active <?php endif; ?>">
                            <a id="account-statement" href=""><?php echo e(trans('file.Account Statement')); ?></a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </li>

                <?php if(Auth::user()->role_id != 5): ?>
                <li>
                    <?php
                    $requestIsOnHRMMenu = request()->is(
                    'departments*',
                    'employees*',
                    'attendance*',
                    'payroll*',
                    'holidays*',
                    )
                    ? 'true'
                    : 'false';
                    ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewany', App\Department::class)): ?>
                    <a href="#hrm" aria-expanded="<?php echo e($requestIsOnHRMMenu); ?>" data-toggle="collapse">
                        <i class="dripicons-user-group"></i><span>HRM</span>
                    </a>
                    <?php endif; ?>
                    <ul id="hrm" class="collapse list-unstyled <?php if($requestIsOnHRMMenu === 'true'): ?> show <?php endif; ?>">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewany', App\Department::class)): ?>
                        <li id="dept-menu" class="<?php if(request()->is('departments*')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('departments.index')); ?>"><?php echo e(trans('file.Department')); ?></a>
                        </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', App\Employee::class)): ?>
                        <li id="employee-menu" class="<?php if(request()->is('employees*')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('employees.index')); ?>"><?php echo e(trans('file.Employee')); ?></a>
                        </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', App\Attendance::class)): ?>
                        <li id="attendance-menu" class="<?php if(request()->is('attendance*')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('attendance.index')); ?>"><?php echo e(trans('file.Attendance')); ?></a>
                        </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', App\Payroll::class)): ?>
                        <li id="payroll-menu" class="<?php if(request()->is('payroll*')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('payroll.index')); ?>"><?php echo e(trans('file.Payroll')); ?></a>
                        </li>
                        <?php endif; ?>

                        <li id="holiday-menu" class="<?php if(request()->is('holidays*')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('holidays.index')); ?>"><?php echo e(trans('file.Holiday')); ?></a>
                        </li>

                    </ul>
                </li>
                <?php endif; ?>

                <?php
                $role = DB::table('roles')->find(Auth::user()->role_id);
                // user permission query original
                $user_index_permission_active = DB::table('permissions')
                ->join('role_has_permissions', 'permissions.id', '=', 'role_has_permissions.permission_id')
                ->where([['permissions.name', 'users-index'], ['role_id', $role->id]])
                ->first();
                ?>

                <li>
                    <?php
                    $requestIsOnPeopleMenu = request()->is('accounts*', 'money-transfers*', 'balancesheet*')
                    ? 'true'
                    : 'false';
                    ?>
                    <a href="#people" aria-expanded="<?php echo e($requestIsOnPeopleMenu); ?>" data-toggle="collapse">
                        <i class="dripicons-user"></i><span><?php echo e(trans('file.People')); ?></span>
                    </a>
                    <ul id="people" class="collapse list-unstyled <?php if($requestIsOnPeopleMenu === 'true'): ?> show <?php endif; ?>">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', App\User::class)): ?>
                        <li id="user-list-menu" class="<?php if(request()->is('user/')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('user.index')); ?>"><?php echo e(trans('file.User List')); ?></a>
                        </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\User::class)): ?>
                        <li id="user-create-menu" class="<?php if(request()->is('user/create/')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('user.create')); ?>"><?php echo e(trans('file.Add User')); ?></a>
                        </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', App\Customer::class)): ?>
                        <li id="customer-list-menu" class="<?php if(request()->is('customer/')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('customer.index')); ?>"><?php echo e(trans('file.Customer List')); ?></a>
                        </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Customer::class)): ?>
                        <li id="customer-create-menu" class="<?php if(request()->is('customer/create/')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('customer.create')); ?>"><?php echo e(trans('file.Add Customer')); ?></a>
                        </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', App\Biller::class)): ?>
                        <li id="biller-list-menu" class="<?php if(request()->is('biller/')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('biller.index')); ?>"><?php echo e(trans('file.Biller List')); ?></a>
                        </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Biller::class)): ?>
                        <li id="biller-create-menu" class="<?php if(request()->is('biller/create/')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('biller.create')); ?>"><?php echo e(trans('file.Add Biller')); ?></a>
                        </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', App\Supplier::class)): ?>
                        <li id="supplier-list-menu" class="<?php if(request()->is('supplier/')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('supplier.index')); ?>"><?php echo e(trans('file.Supplier List')); ?></a>
                        </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Supplier::class)): ?>
                        <li id="supplier-create-menu" class="<?php if(request()->is('supplier/create/')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('supplier.create')); ?>"><?php echo e(trans('file.Add Supplier')); ?></a>
                        </li>
                        <?php endif; ?>

                    </ul>
                </li>

                <li>
                    <?php
                    $requestIsOnReportMenu = request()->is('report*') ? 'true' : 'false';
                    ?>
                    <a href="#report" aria-expanded="<?php echo e($requestIsOnReportMenu); ?>" data-toggle="collapse">
                        <i class="dripicons-document-remove"></i><span><?php echo e(trans('file.Reports')); ?></span>
                    </a>
                    <ul id="report" class="collapse list-unstyled <?php if($requestIsOnReportMenu === 'true'): ?> show <?php endif; ?>">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('report', App\Product::class)): ?>
                        <li <?php if(request()->is('report/sale')): ?> active <?php endif; ?>>
                            <a href="<?php echo e(route('report.sale')); ?>"><?php echo e(trans('file.sale_report')); ?></a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </li>

                <li>
                    <?php
                    $requestIsOnSettingMenu = request()->is(
                    'role*',
                    'warehouse*',
                    'customer_group*',
                    'brand*',
                    'unit*',
                    'currency*',
                    'tax*',
                    'user/porfile*',
                    'setting/createsms*',
                    'backup*',
                    'setting/general_setting*',
                    'setting/mail_setting*',
                    )
                    ? 'true'
                    : 'false';
                    ?>
                    <a href="#setting" aria-expanded="<?php echo e($requestIsOnSettingMenu); ?>" data-toggle="collapse">
                        <i class="dripicons-gear"></i><span><?php echo e(trans('file.settings')); ?></span>
                    </a>
                    <ul id="setting"
                        class="collapse list-unstyled <?php if($requestIsOnSettingMenu === 'true'): ?> show <?php endif; ?>">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', App\Role::class)): ?>
                        <li id="role-menu" class="<?php if(request()->is('role*')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('role.index')); ?>"><?php echo e(trans('file.Role Permission')); ?></a>
                        </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sendNotication')): ?>
                        <li id="notification-menu">
                            <a href="" id="send-notification"><?php echo e(trans('file.Send Notification')); ?></a>
                        </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewany', App\Warehouse::class)): ?>
                        <li id="warehouse-menu" class="<?php if(request()->is('warehouse*')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('warehouse.index')); ?>"><?php echo e(trans('file.Warehouse')); ?></a>
                        </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', App\CustomerGroup::class)): ?>
                        <li id="customer-group-menu" class="<?php if(request()->is('customer_group*')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('customer_group.index')); ?>"><?php echo e(trans('file.Customer Group')); ?></a>
                        </li>
                        <?php endif; ?>

                        

                        

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', App\Tax::class)): ?>
                        <li id="tax-menu" class="<?php if(request()->is('tax*')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('tax.index')); ?>"><?php echo e(trans('file.Tax')); ?></a>
                        </li>
                        <?php endif; ?>

                        <li id="user-menu" class="<?php if(request()->is('user/profile*')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('user.profile', ['id' => Auth::id()])); ?>"><?php echo e(trans('file.User Profile')); ?></a>
                        </li>

                        

                        

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', App\GeneralSetting::class)): ?>
                        <li id="general-setting-menu"
                            class="<?php if(request()->is('setting/general_setting*')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('setting.general')); ?>"><?php echo e(trans('file.General Setting')); ?></a>
                        </li>
                        <?php endif; ?>

                        

                        <li id="invoice-setting-menu"
                            class="<?php if(request()->is('setting/invoice_setting*')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('setting.invoice')); ?>"><?php echo e(trans('file.invoice_setting')); ?></a>
                        </li>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posSetting')): ?>
                        <li id="pos-setting-menu" class="<?php if(request()->is('setting/pos_setting*')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('setting.pos')); ?>">POS <?php echo e(trans('file.settings')); ?></a>
                        </li>
                        <?php endif; ?>

                        
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\laragon\www\tokomas\resources\views/layout/sidebar.blade.php ENDPATH**/ ?>