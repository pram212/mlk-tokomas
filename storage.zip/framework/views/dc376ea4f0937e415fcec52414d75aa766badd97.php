 <?php $__env->startSection('content'); ?>
<?php if(session()->has('message')): ?>
<div class="alert alert-success alert-dismissible text-center"><button type="button" class="close" data-dismiss="alert"
        aria-label="Close"><span aria-hidden="true">&times;</span></button><?php echo session()->get('message'); ?></div>
<?php endif; ?>
<?php if(session()->has('not_permitted')): ?>
<div class="alert alert-danger alert-dismissible text-center"><button type="button" class="close" data-dismiss="alert"
        aria-label="Close"><span aria-hidden="true">&times;</span></button><?php echo e(session()->get('not_permitted')); ?></div>
<?php endif; ?>

<section>
    <div class="container-fluid">
        <div class="card">
            <div class="card-header mt-2">
                <h3 class="text-center"><?php echo e(trans('file.Sale List')); ?></h3>
            </div>
            <div class="card-body">
                <?php echo Form::open(['route' => 'sales.index', 'method' => 'get']); ?>

                <div class="row mb-3 align-items-end">
                    <?php
                    $now = \Carbon\Carbon::now();
                    $date = $now->hour >= 12 ? $now->format('Y-m-d') :
                    $now->subDay()->format('Y-m-d');
                    ?>
                    <div class="col-md-3 mt-3">
                        <div class="form-group">
                            <label class="d-tc mt-2"><strong><?php echo e(trans('file.start_date')); ?></strong> &nbsp;</label>
                            <input type="text" name="start_date" class="form-control datepicker" id="start_date"
                                value="<?php echo e($date); ?>">
                        </div>
                    </div>
                    <div class="col-md-3 mt-3">
                        <div class="form-group">
                            <label class="d-tc mt-2"><strong><?php echo e(trans('file.end_date')); ?></strong> &nbsp;</label>
                            <input type="text" name="end_date" class="form-control datepicker" id="end_date"
                                value="<?php echo e($date); ?>">
                        </div>
                    </div>

                    <div class="col-md-4 mt-3">
                        <div class="form-group">
                            <label class="d-tc mt-2"><strong><?php echo e(trans('file.Warehouse')); ?></strong> &nbsp;</label>
                            <div class="d-tc">
                                <select id="warehouse_id" name="warehouse_id" class="selectpicker form-control"
                                    data-live-search="true" data-live-search-style="begins">
                                    <option value=""><?php echo e(trans('file.All Warehouse')); ?></option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2 mt-3 d-flex align-items-end">
                        <div class="form-group">
                            <button class="btn btn-primary" id="filter-btn"
                                type="button"><?php echo e(trans('file.submit')); ?></button>
                        </div>
                    </div>
                </div>

                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
    <div class="table-responsive">
        <table id="sale-table" class="table sale-list" style="width: 100%">
            <thead>
                <tr>
                    <th><?php echo e(trans('file.No')); ?></th>
                    <th><?php echo e(trans('file.Date')); ?></th>
                    <th><?php echo e(trans('file.Invoice')); ?></th>
                    <th><?php echo e(trans('file.Cashier')); ?></th>
                    <th><?php echo e(trans('file.customer')); ?></th>
                    <th><?php echo e(trans('file.grand total')); ?></th>
                    <th class="not-exported"><?php echo e(trans('file.action')); ?></th>
                </tr>
            </thead>

            <tfoot class="tfoot active">
                <th></th>
                <th><?php echo e(trans('file.Total')); ?></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
            </tfoot>
        </table>
    </div>
</section>

<?php echo $__env->make('sale.partials.modal_sale_detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('sale.partials.modal_sale_view_payment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('sale.partials.modal_sale_add_payment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('sale.partials.modal_sale_add_delivery', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    const lang_records_per_page = '<?php echo e(trans('file.records per page')); ?>';
    const lang_Showing = '<?php echo e(trans('file.Showing')); ?>' ;
    const lang_search = '<?php echo e(trans('file.Search')); ?>' ;
    const lang_PDF = '<?php echo e(trans('file.PDF')); ?>';
    const lang_CSV = '<?php echo e(trans('file.CSV')); ?>';
    const lang_print = '<?php echo e(trans('file.Print')); ?>';
    const lang_delete = '<?php echo e(trans('file.delete')); ?>';
    const lang_visibility = '<?php echo e(trans('file.Column visibility')); ?>';
    const asset_url = '<?php echo e(asset('public/vendor/bootstrap/css/bootstrap.min.css')); ?>';
</script>
<script src="<?php echo e(asset('public/js/pages/sales/sale_index.js?timestamp=' . now()->timestamp)); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tokomas\resources\views/sale/indexNew.blade.php ENDPATH**/ ?>