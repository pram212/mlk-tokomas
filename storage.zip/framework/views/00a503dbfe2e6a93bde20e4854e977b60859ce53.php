<?php $__env->startSection('content'); ?>

<section class="forms">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header d-flex align-items-center">
                        <?php
                        $modeTexts = [
                        'create' => trans('file.Create') . ' ' . trans('file.product'),
                        'edit' => trans('file.Edit') . ' ' . trans('file.product'),
                        'show' => trans('file.Detail') . ' ' . trans('file.product'),
                        ];
                        ?>

                        <div class="card-header d-flex align-items-center">
                            <h4><?php echo e($modeTexts[$mode] ?? ''); ?></h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <p class="italic">
                            <small><?php echo e(trans('file.The field labels marked with * are required input fields')); ?>.</small>
                        </p>
                        <form id="product-form" method="POST"
                            action=" <?php echo e(!isset($product) ? url('products') : url('products/update/' . $product->id)); ?>"
                            enctype="multipart/form-data">

                            <?php echo csrf_field(); ?>
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-12 mb-3">
                                            <label><?php echo e(trans('file.Product Image')); ?> *</label>
                                            <div class="row d-flex justify-content-center">
                                                <div class="col-6">
                                                    <div class="form-group">
                                                        <?php if($mode !='show'): ?>
                                                        <input type="file" name="image" class="form-control" id="image"
                                                            onchange="readURL(this)"
                                                            value="<?php if(@$product): ?><?php echo e(@$product->image); ?><?php endif; ?>">
                                                        <?php endif; ?>
                                                        <small><i>*<?php echo e(trans('Image must be in .jpg, .jpeg, .png
                                                                format
                                                                and maximum 2MB')); ?></i></small>
                                                        <div id="image-preview"
                                                            style="height: 110px; width: 100%; padding: 5px; border-radius: 5px; border: solid #ccc 1px; margin: auto; text-align: center;">
                                                            <!-- Gambar akan ditampilkan di sini -->
                                                        </div>
                                                    </div>
                                                </div>

                                                <?php if($errors->has('image')): ?>
                                                <span>
                                                    <strong><?php echo e($errors->first('image')); ?></strong>
                                                </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-12 mb-3">
                                            <div class="form-group">
                                                <label for=""><?php echo e(__('file.Product Name')); ?> *</label>
                                                <input type="text" class="form-control" name="name"
                                                    value="<?php echo e(old('name', @$product->name)); ?>" id="input-name"
                                                    <?php if($mode=='show' ): ?> readonly <?php endif; ?> required>
                                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('file.Warehouse')); ?> *</strong> </label>
                                                <select name="warehouse_id" class="form-control selectpicker"
                                                    <?php if($mode=='show' ): ?> readonly <?php endif; ?> id="warehouse_id"
                                                    data-live-search="true">
                                                    <option value=""><?php echo e(__('file.Select')); ?></option>
                                                    <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>"
                                                        style="color: <?php echo e($item->color); ?>; font-weight: bold" <?php echo e($item->
                                                        id == @$product->product_warehouse->warehouse_id ?
                                                        'selected' : ''); ?>>
                                                        <?php echo e($item->name); ?>

                                                    </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php $__errorArgs = ['warehouse_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label><?php echo e(__('file.Tag Type Code')); ?> *</strong> </label>
                                                <select name="tag_type_id" class="form-control" <?php if($mode=='show' ): ?>
                                                    readonly <?php endif; ?> id="tag_type_id">
                                                    <option value=""><?php echo e(__('file.Select')); ?></option>
                                                    <?php $__currentLoopData = $tagType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>"
                                                        style="color: <?php echo e($item->color); ?>; font-weight: bold" <?php echo e($item->
                                                        id == @$product->tag_type_id ?
                                                        'selected' : ''); ?>>
                                                        <?php echo e($item->code); ?> - <?php echo e($item->color); ?>

                                                    </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php $__errorArgs = ['tag_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label><?php echo e(trans('file.Product Code')); ?> *</strong> </label>
                                                <div class="input-group">
                                                    <input type="text" name="code" <?php if($mode=='show' ): ?> readonly <?php endif; ?>
                                                        class="form-control" id="code" aria-describedby="code"
                                                        value="<?php echo e(@$product->code); ?>" readonly>
                                                    <div class="input-group-append">
                                                        <button id="genbutton" type="button"
                                                            class="btn btn-sm btn-default"
                                                            title="<?php echo e(trans('file.Generate')); ?>"><i
                                                                class="fa fa-refresh"></i></button>
                                                    </div>
                                                </div>
                                                <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                <span class="validation-msg" id="code-error"></span>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label><?php echo e(__('file.category')); ?> *</strong></label>
                                                        <select data-live-search="true" name="category_id"
                                                            <?php if($mode=='show' ): ?> readonly <?php endif; ?> class="form-control"
                                                            id="input-kd-category">
                                                            <option value=""><?php echo e(__('file.Select')); ?>

                                                            </option>
                                                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($item->id); ?>" <?php if( $item->id ==
                                                                @$product->category_id): ?> selected <?php endif; ?>>
                                                                <?php echo e($item->name); ?>

                                                            </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                        <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label><?php echo e(__('file.Product Type')); ?> * </label>
                                                        <select name="product_type_id" <?php if($mode=='show' ): ?> readonly
                                                            <?php endif; ?> class="form-control selectpicker"
                                                            id="product_type_id" <?php if(!@$product): ?> disabled <?php endif; ?>
                                                            data-live-search="true">
                                                            <option value="" disabled><?php echo e(__('file.Select')); ?></option>
                                                            <?php if(@$product): ?>
                                                            <?php $__currentLoopData = $product_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($item->id); ?>" <?php if($item->id ==
                                                                @$product->product_type_id): ?>
                                                                selected
                                                                <?php endif; ?>>
                                                                <?php echo e($item->code); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>
                                                        </select>
                                                        <?php $__errorArgs = ['product_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for=""><?php echo e(__('file.Gold Content')); ?> *</label>
                                                        <input type="number" <?php if($mode=='show' ): ?> readonly <?php endif; ?>
                                                            class="form-control" name="gold_content"
                                                            value="<?php echo e(old('gold_content', @$product->gold_content)); ?>"
                                                            id="input-gold_content" required>
                                                        <?php $__errorArgs = ['gold_content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>

                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for=""><?php echo e(__('file.Additional Code')); ?> *</label>
                                                        <input type="text" class="form-control" <?php if($mode=='show' ): ?>
                                                            readonly <?php endif; ?> name="additional_code"
                                                            value="<?php echo e(old('additional_code', @$product->additional_code )); ?>"
                                                            id="input-additional_code" required>
                                                        <?php $__errorArgs = ['additional_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label><?php echo e(__('file.Product Property Code')); ?>*</strong> </label>
                                                <select name="product_property_id" <?php if($mode=='show' ): ?> readonly <?php endif; ?>
                                                    class="form-control" id="input-kd-sifat">
                                                    <option value=""><?php echo e(__('file.Select')); ?>

                                                    </option>
                                                    <?php $__currentLoopData = $productProperty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>" <?php if($item->id ==
                                                        @$product->product_property_id): ?> selected <?php endif; ?>>
                                                        <?php echo e($item->code); ?> -
                                                        <?php echo e($item->description); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php $__errorArgs = ['product_property_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label><?php echo e(trans('file.Product Price')); ?> *</strong> </label>
                                                        <input type="text" id="price" name="price" <?php if($mode=='show' ): ?>
                                                            readonly <?php endif; ?> class="form-control" step="any"
                                                            value="<?php echo e(@$product->product_warehouse->price ?? ''); ?>"
                                                            readonly>
                                                        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        <span class="validation-msg"></span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label><?php echo e(__('file.Discount')); ?> *</strong> </label>
                                                        <input type="number" class="form-control" <?php if($mode=='show' ): ?>
                                                            readonly <?php endif; ?> name="discount" id="input-diskon"
                                                            value="<?php echo e(@$product->discount ?? ''); ?>">
                                                        <?php $__errorArgs = ['discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label><?php echo e(__('file.Gramasi')); ?> *</strong></label>
                                                        <div id="text-kd-gramasi"><?php echo e(@$product->gramasi->gramasi ?? '-'); ?>

                                                        </div>
                                                        <input class="form-control" type="hidden" name="gramasi_id"
                                                            id="input-kd-gramasi"
                                                            value="<?php echo e(old('gramasi_id',@$product->gramasi_id)); ?>">
                                                        <?php $__errorArgs = ['gramasi_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>



                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="">Miligram *</label>
                                                        <input type="number" class="form-control" <?php if($mode=='show' ): ?>
                                                            readonly <?php endif; ?> name="mg" class="mg" id="input-mg"
                                                            value="<?php echo e(@$product->mg  ?? ''); ?>">
                                                        <?php $__errorArgs = ['mg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label><?php echo e(trans('file.Split Set Type')); ?> *</strong> </label>
                                                <select name="split_set_type" <?php if($mode=='show' ): ?> readonly <?php endif; ?>
                                                    class="form-control" id="input-split-type">
                                                    <option value=""><?php echo e(__('file.Select')); ?>

                                                    </option>
                                                    <?php $__currentLoopData = $split_set_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item['id']); ?>" <?php if( $item['id']==@$product->
                                                        split_set_type): ?> selected <?php endif; ?>>
                                                        <?php echo e($item['name']); ?>

                                                    </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php $__errorArgs = ['split_set_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div id="detail_split_set" class="bg-dark text-light p-2 d-none">
                                                <div class="row">
                                                    <div class="col-6"><?php echo e(__('file.Detail Split Set')); ?></div>
                                                    <div class="col-6 d-flex justify-content-end"><button type="button"
                                                            class="btn btn-xs btn_historical_split_set"><?php echo e(__('file.Historical Split Set')); ?></button></div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="detail_split_set_qty"><?php echo e(__('file.Product Qty')); ?></label>
                                                    <input class="form-control" type="number"
                                                        name="detail_split_set_qty" id="detail_split_set_qty"
                                                        value="<?php echo e($product->qty ?? 0); ?>">
                                                </div>
                                                <table>
                                                    <tbody>

                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>

                                        <div class="col-md-6"></div>

                                        <div class="col-md-9 border mt-3">
                                            <div class="row" id="product-preview"
                                                style="background-color: <?php echo e(@$product->tagType->color ?? ''); ?>">
                                                <div class="col-md-6 pt-3">
                                                    <div class="row font-weight-bold">
                                                        <div class="col-md-6 mb-3">
                                                            <h1 id="prev-gold_content"></h1>
                                                            
                                                        </div>

                                                        <div class="col-md-6 text-right mb-3">
                                                            <div class="add_disc">
                                                                <span id="prev-additional_code"></span> / <span
                                                                    id="prev-diskon"></span>
                                                            </div>
                                                        </div>

                                                        <div class="col-md-12 text-center">
                                                            <h1 class="d-inline display-4" id="prev-gramasi"></h1>
                                                            <span class="align-top" id="prev-mg"></span>
                                                        </div>

                                                        <div class="col-md-12 text-right">
                                                            <h1 id="prev-kd-sifat"></h1>
                                                        </div>
                                                    </div>

                                                </div>

                                                <div
                                                    class="col-md-6 border border-top-0 border-top-0 border-bottom-0 border-right-0">
                                                    <div class="d-flex align-items-center justify-content-center"
                                                        style="min-height: 200px">
                                                        <div class="text-center" id="prev-qrcode">
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <?php if($mode == 'show'): ?>
                            <div class="card">
                                <div class="card-body">
                                    <div class="row mt-3">
                                        <div class="col-md-12">
                                            <h4>Historical Products</h4>
                                            <table id="detail_historical_products" class="table table-bordered"
                                                width="100%">
                                                <thead>
                                                    <tr>
                                                        <th>No</th>
                                                        <th><?php echo e(__('file.Product Code')); ?></th>
                                                        <th>Status</th>
                                                        <th>Tanggal</th>
                                                        <th>Invoice</th>
                                                        <th><?php echo e(__('file.Product Property')); ?></th>
                                                        <th><?php echo e(__('file.Price')); ?></th>
                                                        <th><?php echo e(__('file.Gramasi')); ?></th>
                                                        <th>Miligram</th>
                                                    </tr>
                                                </thead>
                                                <tbody></tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>

                            <div class="form-group">
                                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-info"><i class="fa fa-arrow-left"></i>
                                    <?php echo e(trans('file.Back')); ?></a>
                                <input type="submit" value="<?php echo e(trans('file.submit')); ?>" id="submit-btn"
                                    class="btn btn-primary">

                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<?php echo $__env->make('product.modal_split_set', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('public/js/qrcode.min.js')); ?>"></script>

<script type="text/javascript">
    const mode = '<?php echo e($mode); ?>';
    const product_id = '<?php echo e(@$product->id); ?>';
    const $input_categories_id = $('#input-kd-category');
    const $input_product_type_id = $('#product_type_id');
    const $input_gramasi_id = $('#input-kd-gramasi');
    const $text_gramasi_id = $('#text-kd-gramasi');
    let old_image = '<?php echo e($product->image ?? ''); ?>';
    const $image_preview = $('#image-preview');
    const $product_property_id = $('#input-kd-sifat');
    const price_col = $('#price');
    const input_split_type = $('#input-split-type');
    const detail_split_set = $('#detail_split_set');
    const genbutton = $('#genbutton');
    const btn_detail_split_add = $('.btn_detail_split_add');
    const btn_detail_split_delete = $('.btn_detail_split_delete');
    let code = $("input[name='code']");
    const table_detail_split_set = $('#detail_split_set table tbody')
    const detail_split_set_qty = $('#detail_split_set_qty');

    const produk = <?php if(@$product): ?> JSON.parse('<?php echo $product; ?>') <?php else: ?> null <?php endif; ?>;
    const product_split_set_detail = <?php if(@$product): ?> produk['product_split_set_detail'] <?php else: ?> null <?php endif; ?>;
    const split_set_id = <?php if(@$split_set_id): ?> <?php echo $split_set_id; ?> <?php else: ?> null <?php endif; ?>;

    const lang_select = '<?php echo __('file.Select'); ?>';

    const gramasis = <?php if(@$gramasi): ?> JSON.parse('<?php echo $gramasi; ?>') <?php else: ?> null <?php endif; ?>;
    const properties = <?php if(@$productProperty): ?> JSON.parse('<?php echo $productProperty; ?>') <?php else: ?> null <?php endif; ?>;

    const btn_historical_split_set = $('.btn_historical_split_set');
    const historical_split_set_modal = $('#historical_split_set_modal');

    const modal_table_detail_split_set = $('#modal_table_detail_split_set tbody');

    const $table_historical = $('#detail_historical_products');

    <?php if($mode == 'show'): ?>
    const split_set_code = '<?php echo e(@$split_set_code); ?>';
    <?php endif; ?>
</script>
<script src="<?php echo e(asset('public/js/pages/products/product_form.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tokomas\resources\views/product/form.blade.php ENDPATH**/ ?>