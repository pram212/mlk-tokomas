<div class="row">
    <?php echo $__env->make('sale.partials.pos_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<div class="row">
    
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col">
                        <select class="form-control" multiple id="filter_category" name="filter_category">
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <table class="table" id="table_product_info" style="width: 100%">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Code</th>
                                    <th>Product Name</th>
                                    <th>Price</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\tokomas\resources\views/sale/partials/pos_information.blade.php ENDPATH**/ ?>