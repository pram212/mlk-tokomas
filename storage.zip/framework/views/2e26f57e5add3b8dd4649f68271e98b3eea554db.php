 <?php $__env->startSection('content'); ?>
<section>
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <select class="form-control" multiple id="filter_warehouse" name="filter_warehouse">
                    </select>
                </div>
                <div class="col-md-6">
                    <select class="form-control" multiple id="filter_status" name="filter_status">
                    </select>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <div class="table-responsive">
                        <table id="product-data-table" class="table" style="width: 100%">
                            <thead>
                                <tr>
                                    <th class="not-exported"></th>
                                    
                                    <th><?php echo e(trans('file.Code')); ?></th>
                                    <th><?php echo e(__('file.Product Name')); ?></th>
                                    <th><?php echo e(__('file.Product Image')); ?></th>
                                    <th><?php echo e(__('file.Warehouse')); ?></th>
                                    <th><?php echo e(__('file.Date')); ?></th>
                                    <th><?php echo e(trans('file.Price')); ?></th>
                                    <th><?php echo e(__('file.Tag Type Code')); ?></th>
                                    <th><?php echo e(__('file.Color')); ?></th>
                                    <th>Miligram</th>
                                    <th>Gramasi</th>
                                    <th><?php echo e(__('file.Product Property')); ?></th>
                                    <th><?php echo e(__('file.Product Status')); ?></th>
                                    <th><?php echo e(__('file.Invoice')); ?></th>

                                </tr>
                            </thead>

                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<script>
    const lang_records_per_page = '<?php echo e(trans("file.records per page")); ?>';
    const lang_Showing = '<?php echo e(trans("file.Showing")); ?>';
    const lang_search = '<?php echo e(trans("file.Search")); ?>';
    const lang_PDF = '<?php echo e(trans("file.PDF")); ?>';
    const lang_CSV = '<?php echo e(trans("file.CSV")); ?>';
    const lang_print = '<?php echo e(trans("file.Print")); ?>';
    const lang_delete = '<?php echo e(trans("file.delete")); ?>';
    const lang_visibility = '<?php echo e(trans("file.Column visibility")); ?>';

    const lang_Type = '<?php echo e(trans("file.Type")); ?>';
    const lang_name = '<?php echo e(trans("file.name")); ?>';
    const lang_Code = '<?php echo e(trans("file.Code")); ?>';
    const lang_Brand = '<?php echo e(trans("file.Brand")); ?>';
    const lang_category = '<?php echo e(trans("file.category")); ?>';
    const lang_Quantity = '<?php echo e(trans("file.Quantity")); ?>';
    const lang_Unit = '<?php echo e(trans("file.Unit")); ?>';
    const lang_Cost = '<?php echo e(trans("file.Cost")); ?>';
    const lang_Price = '<?php echo e(trans("file.Price")); ?>';
    const lang_Tax = '<?php echo e(trans("file.Tax")); ?>';
    const lang_TaxMethod = '<?php echo e(trans("file.Tax Method")); ?>';
    const lang_AlertQuantity = '<?php echo e(trans("file.Alert Quantity")); ?>';
    const lang_ProductDetails = '<?php echo e(trans("file.Product Details")); ?>';
    const lang_ComboProducts = '<?php echo e(trans("file.Combo Products")); ?>';
    const lang_Warehouse = '<?php echo e(trans("file.Warehouse")); ?>';
    const lang_product = '<?php echo e(trans("file.product")); ?>';


    const url_asset_bootstrap = '<?php echo e(asset("public/vendor/bootstrap/css/bootstrap.min.css")); ?>';
</script>
<script src="<?php echo e(asset('public/js/pages/products_stock/product_stock_index.js?timestamp=' . time())); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tokomas\resources\views/product_stock/index.blade.php ENDPATH**/ ?>