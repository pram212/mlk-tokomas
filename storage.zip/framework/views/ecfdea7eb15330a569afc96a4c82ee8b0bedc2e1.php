<?php $__env->startSection('css'); ?>
<style>
    .top-buyback-modal {
        font-size: 13px;
        font-weight: bold;
        border-bottom: 1px solid rgba(99, 99, 99, 0.3);
        padding-bottom: 10px;
    }

    .top-buyback-modal td {
        padding-right: 10px;
    }
</style>
<?php $__env->stopSection(); ?>

<div class="modal fade" id="buybackModal" tabindex="-1" role="dialog" aria-labelledby="buybackModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div class="row p-2">
                    <span class="buybackModalLabel" id="buybackModalLabel">Perhitungan
                        BuyBack
                    </span>
                    <img class="mr-2 "
                        src="data:image/png;base64,<?php echo e(base64_encode(file_get_contents(public_path('logo/bima_logo_1.png')))); ?>"
                        height="40px" alt="">
                    <img class=""
                        src="data:image/png;base64,<?php echo e(base64_encode(file_get_contents(public_path('logo/bima_text_1.png')))); ?>"
                        height="40px" alt="">
                </div>

                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body">
                <div class="row top-buyback-modal">
                    <div class="col">
                        <table>
                            <tbody>
                                <tr>
                                    <td>Catatan Penjualan</td>
                                    <td>:</td>
                                    <td><span id="sale_note"></span></td>
                                </tr>
                                <tr>
                                    <td>Gramasi</td>
                                    <td>:</td>
                                    <td><span id="gramasi"></span></td>
                                </tr>
                                <tr>
                                    <td>Sifat Barang</td>
                                    <td>:</td>
                                    <td><span id="product_property"></span></td>
                                </tr>
                                <tr>
                                    <td>Invoice</td>
                                    <td>:</td>
                                    <td><span id="invoice_number_sales"></span></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col-md-6">
                        <div class="row p-2 modal_desc">
                            <p id="modal_desc_value"></p>
                            <span>Deskripsi</span>
                        </div>
                        <div class="row p-2 modal_price">
                            <p id="modal_price_value"></p>
                            <span>Harga</span>
                        </div>
                    </div>
                    <div class="col-md-6 p-2 modal_right">
                        <div class="row mb-2">
                            <div class="col-md-6">Harga Awal</div>
                            <div class="col-md-6">
                                <input type="text" class="form-control" id="modal_price_default" readonly>
                                <input type="hidden" class="form-control" id="product_id">
                                <input type="hidden" class="form-control" id="product_code">
                                <input type="hidden" class="form-control" id="final_price">
                            </div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-md-6">Potongan</div>
                            <div class="col-md-6">
                                <input type="text" class="form-control" id="modal_discount" readonly>
                                <div class="form-group form-check" title="Potongan akan dikalikan 2 jika ini diceklis!">
                                    <input type="checkbox" class="form-check-input" id="barang_meleot">
                                    <label class="form-check-label" for="barang_meleot">Barang meleot dekok</label>
                                </div>
                            </div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-md-6">Biaya tambahan</div>
                            <div class="col-md-6">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('buybackEdit', App\Product::class)): ?>
                                <div class="input-group mb-3">
                                    <input type="int" class="form-control" onchange="hitungTotalPotongan()"
                                        id="modal_additional_cost" value="0">
                                    <div class="input-group-append">
                                        <button class="btn btn-outline-success" type="button"
                                            id="btn_save_additional_cost"><i class="fa fa-save"></i></button>
                                    </div>
                                </div>
                                <?php else: ?>
                                <input type="int" class="form-control" id="modal_additional_cost" value="0" readonly>
                                <?php endif; ?>
                            </div>

                        </div>
                        <div class="row mb-2">
                            <div class="col-md-6">Keterangan</div>
                            <div class="col-md-6"><input type="text" class="form-control" id="modal_description">
                            </div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-md-6">Totalnya potongan</div>
                            <div class="col-md-6"><input type="text" class="form-control" id="modal_total_discount"
                                    value="0" readonly>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <button type="button" class="btn btn-primary" id="btn_submit">Beli Kembali</button>
                            </div>
                            <div class="col-md-6">
                                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                            </div>
                        </div>
                        

                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\tokomas\resources\views/partials/buyback/modal_buyback.blade.php ENDPATH**/ ?>