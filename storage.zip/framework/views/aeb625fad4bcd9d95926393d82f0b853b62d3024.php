<?php $__env->startSection('content'); ?>
    <section>
        <div class="container-fluid">
            <div class="card">
                <div class="card-header d-flex align-items-center">
                    <h4><?php echo e(__('file.Price')); ?></h4>
                </div>

                <div class="card-body">
                    <?php $__errorArgs = ['duplicate_data'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <strong><?php echo e($message); ?></strong>
                        </div>

                        <script>
                            $(".alert").alert();
                        </script>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    
                    <span style="background-color: #e69a1e; height:70%px; width: 100%;"></span>
                    <p class="italic">
                        <small><?php echo e(trans('file.The field labels marked with * are required input fields')); ?>.</small>
                    </p>
                    <?php
                        $action = @$price ? route('master.price.update', @$price->id) : route('master.price.store');
                    ?>
                    <form action="<?php echo e($action); ?>" class="row" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php if(@$price): ?>
                            <?php echo method_field('put'); ?>
                        <?php endif; ?>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label><?php echo e(__('file.Price')); ?> *</strong> </label>
                                <input type="text" name="price" class="form-control" id="price"
                                    value="<?php echo e(old('price', @$price->price)); ?>">
                                <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label><?php echo e(__('file.Product Property')); ?> *</strong></label>
                                <select name="product_property_id" class="form-control" id="input-kd-gramasi">
                                    <option value=""><?php echo e(__('file.Select')); ?>

                                    </option>
                                    <?php $__currentLoopData = $productProperty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"
                                            <?php if($item->id == @$price->product_property_id): ?> selected <?php endif; ?>>
                                            <?php echo e($item->code); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['product_property_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label><?php echo e(__('file.Gramasi Code')); ?> *</strong></label>
                                <select name="gramasi_id" class="form-control" id="input-kd-gramasi">
                                    <option value=""><?php echo e(__('file.Select')); ?>

                                    </option>
                                    <?php $__currentLoopData = $gramasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"
                                            <?php if($item->id == @$price->gramasi_id): ?> selected <?php endif; ?>>
                                            <?php echo e($item->code); ?> - <?php echo e($item->gramasi); ?> gr</option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['gramasi_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label><?php echo e(__('file.Created By')); ?> *</strong></label>
                                <input type="text" name="created_by" class="form-control" id="created_by"
                                    value="<?php echo e(auth()->user()->name); ?>" disabled>
                                <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <button class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $("#price").maskMoney()
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\mlk-tokomas\resources\views/price/form.blade.php ENDPATH**/ ?>