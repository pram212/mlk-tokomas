 <?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('public/css/pages/buyback/buyback_list.css')); ?>">
<section>
    <div class="container-fluid">
        <div class="row">
            
            <div class=" col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4><?php echo e(__('file.buy back')); ?> List </h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group row">
                                    <label for="invoice_number" class="col-md-4 col-form-label text-md-right"><?php echo e(__('file.Invoice')); ?></label>
                                    <div class="col-md-8">
                                        
                                        <div class="form-group">
                                            <select class="form-control" id="invoice_number" name="invoice_number"
                                                data-live-search="true">
                                                <option value=""><?php echo e(__('file.Select')); ?></option>
                                            </select>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group row">
                                    <label for="code" class="col-md-4 col-form-label text-md-right">
                                        <?php echo e(__('file.Product Code')); ?></label>
                                    <div class="col-md-8">
                                        <div class="form-group">
                                            <select class="form-control" id="code" name="code" data-live-search="true">
                                                <option value=""><?php echo e(__('file.Select')); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-2">
                                <div class="form-group row">
                                    <div class="col-md-12">
                                        <button type="button" class="btn btn-primary" id="filter">
                                            <?php echo e(__('file.Filter')); ?>

                                        </button>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="table-responsive">
                                <table id="buyback-data-table" class="table" style="width: 100%">
                                    <thead>
                                        <tr>
                                            <th><?php echo e(trans('file.Code')); ?></th>
                                            <th><?php echo e(__('file.Product Name')); ?></th>
                                            <th><?php echo e(__('file.Product Image')); ?></th>
                                            <th><?php echo e(__('file.Date')); ?></th>
                                            <th><?php echo e(trans('file.Price')); ?></th>
                                            <th><?php echo e(__('file.Tag Type Code')); ?></th>
                                            <th><?php echo e(__('file.Color')); ?></th>
                                            <th>Miligram</th>
                                            <th>Gramasi</th>
                                            <th><?php echo e(__('file.Product Status')); ?></th>
                                            <th><?php echo e(__('file.Invoice')); ?></th>
                                            <th>Buy Back Status</th>
                                            <th class="not-exported"><?php echo e(trans('file.action')); ?></th>
                                        </tr>
                                    </thead>

                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<?php echo $__env->make('partials.buyback.modal_buyback', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    const lang_visibility = '<?php echo e(__("file.Column visibility")); ?>';
    const lang_select = '<?php echo e(__("file.Select")); ?>';
</script>
<script src="<?php echo e(asset('public/js/pages/buyback/buyback_list.js?timestamp=' . now()->timestamp)); ?>"></script>
<script src="<?php echo e(asset('public/js/pages/buyback/modal/buyback_modal.js?timestamp=' . now()->timestamp)); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tokomas\resources\views/buyback/index.blade.php ENDPATH**/ ?>