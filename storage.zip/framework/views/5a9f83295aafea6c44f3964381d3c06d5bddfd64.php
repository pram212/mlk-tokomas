<div id="today-profit-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true"
    class="modal fade text-left">
    <div role="document" class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 id="exampleModalLabel" class="modal-title"><?php echo e(trans('file.Today Profit')); ?></h5>
                <button type="button" data-dismiss="modal" aria-label="Close" class="close"><span
                        aria-hidden="true"><i class="dripicons-cross"></i></span></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6">
                        <select required name="warehouseId" class="form-control">
                            <option value="0"><?php echo e(trans('file.All Warehouse')); ?></option>
                            <?php $__currentLoopData = $lims_warehouse_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($warehouse->id); ?>"><?php echo e($warehouse->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-12 mt-2">
                        <table class="table table-hover">
                            <tbody>
                                <tr>
                                    <td><?php echo e(trans('file.Product Revenue')); ?>:</td>
                                    <td class="product_revenue text-right"></td>
                                </tr>
                                <tr>
                                    <td><?php echo e(trans('file.Product Cost')); ?>:</td>
                                    <td class="product_cost text-right"></td>
                                </tr>
                                <tr>
                                    <td><?php echo e(trans('file.Expense')); ?>:</td>
                                    <td class="expense_amount text-right"></td>
                                </tr>
                                <tr>
                                    <td><strong><?php echo e(trans('file.Profit')); ?>:</strong></td>
                                    <td class="profit text-right"></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\laragon\www\mlk-tokomas\resources\views/sale/today_profit_modal.blade.php ENDPATH**/ ?>