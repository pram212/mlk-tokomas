<?php if($show_buyback_button): ?>
<div class="dropdown">
    <button class="btn btn-outline-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown"
        aria-haspopup="true" aria-expanded="false">
        Action
    </button>
    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
        <a class="dropdown-item btn-buyback" href="#" data-productId="<?php echo e($product->id); ?>"
            data-productCode="<?php echo e($product->code); ?>"><i class="fa fa-arrow-left"></i> Buyback</a>
    </div>
</div>
<?php else: ?>
<button class="btn btn-default dropdown-toggle" type="button" disabled>
    Action
</button>
<?php endif; ?><?php /**PATH C:\laragon\www\tokomas\resources\views/buyback/index_action.blade.php ENDPATH**/ ?>