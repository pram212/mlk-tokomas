<?php $__env->startSection('title', trans('file.Gramasi')); ?>
<?php $__env->startSection('content'); ?>
<?php if(session()->has('create_message')): ?>
<div class="alert alert-success alert-dismissible text-center"><button type="button" class="close" data-dismiss="alert"
        aria-label="Close"><span aria-hidden="true">&times;</span></button><?php echo e(session()->get('create_message')); ?></div>
<?php endif; ?>
<?php if(session()->has('edit_message')): ?>
<div class="alert alert-success alert-dismissible text-center"><button type="button" class="close" data-dismiss="alert"
        aria-label="Close"><span aria-hidden="true">&times;</span></button><?php echo e(session()->get('edit_message')); ?></div>
<?php endif; ?>
<?php if(session()->has('import_message')): ?>
<div class="alert alert-success alert-dismissible text-center"><button type="button" class="close" data-dismiss="alert"
        aria-label="Close"><span aria-hidden="true">&times;</span></button><?php echo e(session()->get('import_message')); ?></div>
<?php endif; ?>
<?php if(session()->has('not_permitted')): ?>
<div class="alert alert-danger alert-dismissible text-center"><button type="button" class="close" data-dismiss="alert"
        aria-label="Close"><span aria-hidden="true">&times;</span></button><?php echo e(session()->get('not_permitted')); ?></div>
<?php endif; ?>
<?php if(session()->has('message')): ?>
<div class="alert alert-danger alert-dismissible text-center"><button type="button" class="close" data-dismiss="alert"
        aria-label="Close"><span aria-hidden="true">&times;</span></button><?php echo e(session()->get('message')); ?></div>
<?php endif; ?>
<section>
    <div class="container">
        <div class="card">
            <div class="card-header d-flex align-items-center">
                <h4><?php echo e($subTitle); ?></h4>
            </div>

            <div class="card-body">
                <p class="italic">
                    <small><?php echo e(trans('file.The field labels marked with * are required input fields')); ?>.</small>
                </p>
                <?php
                $action = @$gramasi ? route('product-categories.gramasi.update', @$gramasi->id) :
                route('product-categories.gramasi.store');
                ?>
                <?php $__errorArgs = ['duplicate_data'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <strong><?php echo e($message); ?></strong>
                </div>

                <script>
                    $(".alert").alert();
                </script>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <form action="<?php echo e($action); ?>" class="row" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php if(@$gramasi): ?>
                    <?php echo method_field('put'); ?>
                    <?php endif; ?>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label><strong><?php echo e(__('file.Product Category')); ?> *</strong> </label>
                            <select name="categories_id" class="form-control" id="categories_id"
                                data-live-search="true">
                                <option value=""><?php echo e(__('file.Select')); ?></option>
                                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>" <?php echo e(old('categories_id', @$gramasi->categories_id) ==
                                    $item->id ? 'selected' : ''); ?>>
                                    <?php echo e($item->name); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['categories_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label><strong><?php echo e(__('file.Product Gramasi Type Code')); ?> *</strong> </label>
                            <input type="text" name="code" class="form-control" id="code"
                                value="<?php echo e(old('code', @$gramasi->code)); ?>">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label><strong><?php echo e(__('file.Product Type')); ?> *</strong> </label>
                            <select name="product_type_id" class="form-control selectpicker" id="product_type_id"
                                disabled data-live-search="true">
                                <option value="" disabled><?php echo e(__('file.Select')); ?></option>
                            </select>
                            <?php $__errorArgs = ['product_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label><strong><?php echo e(__('file.Gramasi')); ?> *</strong> </label>
                            <input type="number" name="gramasi" class="form-control" id="gramasi"
                                value="<?php echo e(old('gramasi', @$gramasi->gramasi)); ?>">
                            <?php $__errorArgs = ['gramasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <button class="btn btn-primary"><?php echo e(__('file.submit')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<script>
    let product_type_id = $('#product_type_id');
    let button_product_type_id = $('button[data-id="product_type_id"]');
    let old_product_type_id = '<?php echo e(old('product_type_id', @$gramasi->product_type_id)); ?>';
        
    $('#categories_id').change(function() {
        let categories_id = $(this).val();
       
        getProductType(categories_id);
    });

    function getProductType(categories_id) {
        $.ajax({
            type: "GET",
            url: "<?php echo e(url('product-categories/producttype-getByCategory/')); ?>/" + categories_id,
            success: function(data) {
                let res =data;
                button_product_type_id.toggleClass('disabled', res.data.length == 0);
                product_type_id.prop('disabled', res.data.length == 0);

                let options = '<option value=""><?php echo e(__('file.Select')); ?></option>';
                if (res.data.length != 0)
                res.data.forEach(element => {
                    options += `<option value="${element.id}">${element.code}</option>`;
                });
                
                product_type_id.html(options);

                // trigger change to set the value
                $('.selectpicker').selectpicker('refresh');
            }
        });
    }

    $('#product_type_id').change(function() {
            var selectedText = $(this).find('option:selected').text();
            var code = selectedText.split('-')[0];
            $("#product_code").val(code);
        });
    

    // on load
    $(document).ready(function() {
        // if edit mode
    <?php if(@$gramasi): ?>
    let categories_id = '<?php echo e(@$gramasi->categories_id); ?>';
    let product_type_id = '<?php echo e(@$gramasi->product_type_id); ?>';

    // // trigger change to set the value
    $('#categories_id').trigger('change');

    // set #product_type_id selected value
    // wait for #product_type_id to be enabled
    setTimeout(() => {
        $('#product_type_id').val(product_type_id);
    $('#product_type_id').trigger('change');
    }, 1000);

    // trigger change to set the value
    <?php endif; ?>

    // if add mode, set the value of product_type_id
    <?php if(!@$gramasi): ?>
    let categories_id = '<?php echo e(old('categories_id')); ?>';

    // trigger change to set the value
    $('#categories_id').trigger('change');

    // set #product_type_id selected value
    // wait for #product_type_id to be enabled
    setTimeout(() => {
        $('#product_type_id').val(old_product_type_id);
    $('#product_type_id').trigger('change');
    }, 1000);
    <?php endif; ?>
    });
    
    
    
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tokomas\resources\views/gramasi/form.blade.php ENDPATH**/ ?>