<div class="dropdown">
    <button class="btn btn-outline-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown"
        aria-haspopup="true" aria-expanded="false">
        Action
    </button>
    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
        <a class="dropdown-item btn-view" href="#" data-id="<?php echo e($product->id); ?>"><i class="fa fa-eye"></i> View</a>
        <?php if($product->product_status == 1 && $user->can('update', $product)): ?>
        <a class="dropdown-item btn-edit" href="<?php echo e(($product->split_set_code) ? url("products/$product->id/edit?split_set_id=$product->split_id"):url("products/$product->id/edit")); ?>"><i
                class="fa fa-edit"></i> Edit</a>
        <?php endif; ?>

        <a class="dropdown-item btn-print" target="_BLANK" data-id="<?php echo e($product->id); ?>" href="<?php echo e(url("products/print/$product->id")); ?>"><i class="fa fa-print"></i> Print</a>

        <?php if($product->product_status == 1 && $user->can('delete', $product)): ?>
        <a class="dropdown-item btn-delete" href="#" data-id="<?php echo e($product->id); ?>"
            data-splitid="<?php echo e($product->split_id); ?>"><i class="fa fa-trash"></i> Delete</a>
        <?php endif; ?>
    </div>
</div><?php /**PATH C:\laragon\www\tokomas\resources\views/product/index_action.blade.php ENDPATH**/ ?>