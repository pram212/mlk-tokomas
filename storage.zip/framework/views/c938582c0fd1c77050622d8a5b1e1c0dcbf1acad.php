<h1>Hey <?php echo e($name); ?>!</h1>
<h3>A GiftCard has successfully created for You. Card no: <?php echo e($card_no); ?>.</h3>
<p>Your current balance is: <?php echo e($amount); ?></p>
<p>GiftCard expired date is: <?php echo e($expired_date); ?></p>
<p>Thank you</p><?php /**PATH D:\laragon\www\mlk-tokomas\resources\views/mail/gift_card_create.blade.php ENDPATH**/ ?>