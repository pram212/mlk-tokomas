 <?php $__env->startSection('content'); ?>
<section>
    <div class="container-fluid">
        
        <a href="<?php echo e(route('warehouse_transfer.create')); ?>" class="btn btn-info"><i class="dripicons-plus"></i>
            <?php echo e(__('file.warehouse_transfer_add')); ?></a>
        
    </div>
    <div class="table-responsive">
        <table id="data-table" class="table" style="width: 100%">
            <thead>
                <tr>
                    <th class="not-exported"><?php echo e(__('file.No')); ?></th>
                    <th><?php echo e(__('file.Product Name')); ?></th>
                    <th><?php echo e(__('file.warehouse_transfer_date')); ?></th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>
</section>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    const lang_records_per_page = '<?php echo e(trans("file.records per page")); ?>';
    const lang_Showing = '<?php echo e(trans("file.Showing")); ?>';
    const lang_search = '<?php echo e(trans("file.Search")); ?>';
    const lang_PDF = '<?php echo e(trans("file.PDF")); ?>';
    const lang_CSV = '<?php echo e(trans("file.CSV")); ?>';
    const lang_print = '<?php echo e(trans("file.Print")); ?>';
    const lang_delete = '<?php echo e(trans("file.delete")); ?>';
    const lang_visibility = '<?php echo e(trans("file.Column visibility")); ?>';
</script>
<script src="<?php echo e(asset('public/js/pages/warehouse_transfer/warehouse_transfer_index.js?timestamp=' . time())); ?>">
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tokomas\resources\views/warehouse_transfer/index.blade.php ENDPATH**/ ?>