<div id="add-delivery" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true"
  class="modal fade text-left">
  <div role="document" class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 id="exampleModalLabel" class="modal-title"><?php echo e(trans('file.Add Delivery')); ?></h5>
        <button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true"><i
              class="dripicons-cross"></i></span></button>
      </div>
      <div class="modal-body">
        <?php echo Form::open(['route' => 'delivery.store', 'method' => 'post', 'files' => true]); ?>

        <div class="row">
          <div class="col-md-6 form-group">
            <label><?php echo e(trans('file.Delivery Reference')); ?></label>
            <p id="dr"></p>
          </div>
          <div class="col-md-6 form-group">
            <label><?php echo e(trans('file.Sale Reference')); ?></label>
            <p id="sr"></p>
          </div>
          <div class="col-md-12 form-group">
            <label><?php echo e(trans('file.Status')); ?> *</label>
            <select name="status" required class="form-control selectpicker">
              <option value="1"><?php echo e(trans('file.Packing')); ?></option>
              <option value="2"><?php echo e(trans('file.Delivering')); ?></option>
              <option value="3"><?php echo e(trans('file.Delivered')); ?></option>
            </select>
          </div>
          <div class="col-md-6 mt-2 form-group">
            <label><?php echo e(trans('file.Delivered By')); ?></label>
            <input type="text" name="delivered_by" class="form-control">
          </div>
          <div class="col-md-6 mt-2 form-group">
            <label><?php echo e(trans('file.Recieved By')); ?> </label>
            <input type="text" name="recieved_by" class="form-control">
          </div>
          <div class="col-md-6 form-group">
            <label><?php echo e(trans('file.customer')); ?> *</label>
            <p id="customer"></p>
          </div>
          <div class="col-md-6 form-group">
            <label><?php echo e(trans('file.Attach File')); ?></label>
            <input type="file" name="file" class="form-control">
          </div>
          <div class="col-md-6 form-group">
            <label><?php echo e(trans('file.Address')); ?> *</label>
            <textarea rows="3" name="address" class="form-control" required></textarea>
          </div>
          <div class="col-md-6 form-group">
            <label><?php echo e(trans('file.Note')); ?></label>
            <textarea rows="3" name="note" class="form-control"></textarea>
          </div>
        </div>
        <input type="hidden" name="reference_no">
        <input type="hidden" name="sale_id">
        <button type="submit" class="btn btn-primary"><?php echo e(trans('file.submit')); ?></button>
        <?php echo e(Form::close()); ?>

      </div>
    </div>
  </div>
</div><?php /**PATH C:\laragon\www\tokomas\resources\views/sale/partials/modal_sale_add_delivery.blade.php ENDPATH**/ ?>