 <?php $__env->startSection('content'); ?>
<section>
    <div class="container-fluid">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Product::class)): ?>
        <a href="<?php echo e(route('products.create')); ?>" class="btn btn-info"><i class="dripicons-plus"></i>
            <?php echo e(__('file.add_product')); ?></a>
        <a href="#" data-toggle="modal" data-target="#importProduct" class="btn btn-primary"><i
                class="dripicons-copy"></i> <?php echo e(__('file.import_product')); ?></a>
        <?php endif; ?>
    </div>
    <div class="table-responsive">
        <table id="product-data-table" class="table" style="width: 100%">
            <thead>
                <tr>
                    <th class="not-exported"></th>
                    
                    <th><?php echo e(trans('file.Code')); ?></th>
                    <th><?php echo e(__('file.Product Name')); ?></th>
                    <th><?php echo e(__('file.Product Image')); ?></th>
                    <th><?php echo e(__('file.Date')); ?></th>
                    <th><?php echo e(trans('file.Price')); ?></th>
                    <th><?php echo e(__('file.Tag Type Code')); ?></th>
                    <th><?php echo e(__('file.Color')); ?></th>
                    <th>Miligram</th>
                    <th>Gramasi</th>
                    <th><?php echo e(__('file.Product Property')); ?></th>
                    <th><?php echo e(__('file.Product Status')); ?></th>
                    <th><?php echo e(__('file.Invoice')); ?></th>
                    <th class="not-exported"><?php echo e(trans('file.action')); ?></th>
                </tr>
            </thead>

        </table>
    </div>
</section>

<div id="importProduct" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true"
    class="modal fade text-left">
    <div role="document" class="modal-dialog">
        <div class="modal-content">
            <?php echo Form::open(['route' => 'products.import', 'method' => 'post', 'files' => true]); ?>

            <div class="modal-header">
                <h5 id="exampleModalLabel" class="modal-title">Import Product</h5>
                <button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true"><i
                            class="dripicons-cross"></i></span></button>
            </div>
            <div class="modal-body">
                <p class="italic">
                    <small><?php echo e(trans('file.The field labels marked with * are required input fields')); ?>.</small>
                </p>
                <p><?php echo e(trans('file.The correct column order is')); ?> (image, name*, code*, type*, brand, category*,
                    unit_code*, cost*, price*, product_details, variant_name, item_code, additional_price)
                    <?php echo e(trans('file.and you must follow this')); ?>.
                </p>
                <p><?php echo e(trans('file.To display Image it must be stored in')); ?> public/images/product
                    <?php echo e(trans('file.directory')); ?>. <?php echo e(trans('file.Image name must be same as product name')); ?>

                </p>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label><?php echo e(trans('file.Upload CSV File')); ?> *</label>
                            <?php echo e(Form::file('file', ['class' => 'form-control', 'required'])); ?>

                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label> <?php echo e(trans('file.Sample File')); ?></label>
                            <a href="public/sample_file/sample_products.csv" class="btn btn-info btn-block btn-md"><i
                                    class="dripicons-download"></i> <?php echo e(trans('file.Download')); ?></a>
                        </div>
                    </div>
                </div>
                <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>

            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>

<div id="product-details" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true"
    class="modal fade text-left">
    <div role="document" class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 id="exampleModalLabel" class="modal-title"><?php echo e(trans('Product Details')); ?></h5>
                <button id="print-btn" type="button" class="btn btn-default btn-sm ml-3"><i class="dripicons-print"></i>
                    <?php echo e(trans('file.Print')); ?></button>
                <button type="button" id="close-btn" data-dismiss="modal" aria-label="Close" class="close"><span
                        aria-hidden="true"><i class="dripicons-cross"></i></span></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-5" id="slider-content"></div>
                    <div class="col-md-5 offset-1" id="product-content"></div>
                    <div class="col-md-5 mt-2" id="product-warehouse-section">
                        <h5><?php echo e(trans('file.Warehouse Quantity')); ?></h5>
                        <table class="table table-bordered table-hover product-warehouse-list">
                            <thead>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                    <div class="col-md-7 mt-2" id="product-variant-warehouse-section">
                        <h5><?php echo e(trans('file.Warehouse quantity of product variants')); ?></h5>
                        <table class="table table-bordered table-hover product-variant-warehouse-list">
                            <thead>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>

                <h5 id="combo-header"></h5>
                <table class="table table-bordered table-hover item-list">
                    <thead>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="detailModal" tabindex="-1" role="dialog" aria-labelledby="detailModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="detailModalLabel"><?php echo e(__('file.Product Details')); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row">

                    <div class="col-12 mb-3 border">
                        <div class="h-100 d-flex align-items-center justify-content-center">
                            <div class="text-center" id="prev-qrcode">
                            </div>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="form-group">
                            <label for="code"><?php echo e(__('file.Product Code')); ?> :</label>
                            <input type="text" id="dtl-code" class="form-control" readonly>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="form-group">
                            <label for="code"><?php echo e(__('file.Price')); ?> :</label>
                            <input type="text" id="dtl-price" class="form-control" readonly>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="form-group">
                            <label for="code"><?php echo e(__('file.Tag Type Code')); ?> :</label>
                            <input type="text" id="dtl-tag-code" class="form-control" readonly>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="form-group">
                            <label for="code"><?php echo e(__('file.Gramasi Code')); ?> :</label>
                            <input type="text" id="dtl-gramasi-code" class="form-control" readonly>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label for="code"><?php echo e(__('file.Discount')); ?> :</label>
                            <input type="text" id="dtl-discount" class="form-control" readonly>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label for="code"><?php echo e(__('file.Product Property Code')); ?> :</label>
                            <input type="text" id="dtl-product-property" class="form-control" readonly>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<script src="<?php echo e(asset('public/js/qrcode.min.js')); ?>"></script>
<script>
    const lang_records_per_page = '<?php echo e(trans("file.records per page")); ?>';
    const lang_Showing = '<?php echo e(trans("file.Showing")); ?>';
    const lang_search = '<?php echo e(trans("file.Search")); ?>';
    const lang_PDF = '<?php echo e(trans("file.PDF")); ?>';
    const lang_CSV = '<?php echo e(trans("file.CSV")); ?>';
    const lang_print = '<?php echo e(trans("file.Print")); ?>';
    const lang_delete = '<?php echo e(trans("file.delete")); ?>';
    const lang_visibility = '<?php echo e(trans("file.Column visibility")); ?>';

    const lang_Type = '<?php echo e(trans("file.Type")); ?>';
    const lang_name = '<?php echo e(trans("file.name")); ?>';
    const lang_Code = '<?php echo e(trans("file.Code")); ?>';
    const lang_Brand = '<?php echo e(trans("file.Brand")); ?>';
    const lang_category = '<?php echo e(trans("file.category")); ?>';
    const lang_Quantity = '<?php echo e(trans("file.Quantity")); ?>';
    const lang_Unit = '<?php echo e(trans("file.Unit")); ?>';
    const lang_Cost = '<?php echo e(trans("file.Cost")); ?>';
    const lang_Price = '<?php echo e(trans("file.Price")); ?>';
    const lang_Tax = '<?php echo e(trans("file.Tax")); ?>';
    const lang_TaxMethod = '<?php echo e(trans("file.Tax Method")); ?>';
    const lang_AlertQuantity = '<?php echo e(trans("file.Alert Quantity")); ?>';
    const lang_ProductDetails = '<?php echo e(trans("file.Product Details")); ?>';
    const lang_ComboProducts = '<?php echo e(trans("file.Combo Products")); ?>';
    const lang_Warehouse = '<?php echo e(trans("file.Warehouse")); ?>';
    const lang_product = '<?php echo e(trans("file.product")); ?>';


    const url_asset_bootstrap = '<?php echo e(asset("public/vendor/bootstrap/css/bootstrap.min.css")); ?>';
</script>
<script src="<?php echo e(asset('public/js/pages/products/product_index.js?timestamp=' . time())); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tokomas\resources\views/product/index.blade.php ENDPATH**/ ?>